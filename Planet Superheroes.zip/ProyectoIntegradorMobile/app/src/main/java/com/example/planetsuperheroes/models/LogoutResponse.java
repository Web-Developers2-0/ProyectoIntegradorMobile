package com.example.planetsuperheroes.models;

public class LogoutResponse {
    private boolean success;
}