package com.example.planetsuperheroes.models;

public class LogoutRequest {
    private int user;

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }
}