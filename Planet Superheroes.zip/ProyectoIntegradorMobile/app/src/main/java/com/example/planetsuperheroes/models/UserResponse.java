package com.example.planetsuperheroes.models;

public class UserResponse {
    private String message;
    private boolean success;

    // Getters
    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }
}
