package com.example.planetsuperheroes.models;

public class LoginResponse {
    private String token;

    // Getter and setter
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}

